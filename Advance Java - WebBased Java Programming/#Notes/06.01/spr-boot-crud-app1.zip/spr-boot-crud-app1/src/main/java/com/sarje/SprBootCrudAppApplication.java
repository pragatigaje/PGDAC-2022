package com.sarje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprBootCrudAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprBootCrudAppApplication.class, args);
	}

}
