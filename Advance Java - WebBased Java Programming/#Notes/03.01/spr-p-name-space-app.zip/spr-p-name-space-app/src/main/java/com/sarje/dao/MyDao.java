package com.sarje.dao;

public class MyDao {
 public void save() {
	 System.out.println("save called");
 }
}
