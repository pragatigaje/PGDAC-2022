package com.sarje.dao;

public class MyDao {
	
 public MyDao() {
		System.out.println("no-arg MyDao is called");
	}

public void save() {
	 System.out.println("save called");
 }
}
