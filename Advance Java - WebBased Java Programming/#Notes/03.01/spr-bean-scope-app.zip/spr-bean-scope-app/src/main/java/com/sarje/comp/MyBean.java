package com.sarje.comp;

public class MyBean {

	public MyBean() {
		System.out.println("constructor called");
	}
	
	
	
}
